#Sawyer Rietveld
#M08 Final Project Submission
#Turn-Based Game

playerHealth = 100 #Variable for the player's health
enemyHealth = 200 #Variable for the enemy's health
playerDamage = 0 #Variable for the player's damage
enemyDamage = 0 #Variable for the enemy's damage
specialDamage = 0 #Variable for the damage dealt by the player's special
endGame = False #Variable that gets changed to True if the player or enemy's health fall to 0
playerDisplayMessage = "" #Variable for the message that displays beneath the player
enemyDisplayMessage = "" #Variable for the message that displays beneath the enemy
healLimit = 3 #Variable for the max amount of times the player can heal
endMessage = "" #Variable that gets changed to "You win" or "You lose" depending on the winner of the game

#Counters for the end-of-game statistics
damageDealtCount = 0
damageTakenCount = 0
playerMissCount = 0
playerCritCount = 0
playerHealCount = 0
enemyMissCount = 0
enemyCritCount = 0

#Imports modules
import random
from breezypythongui import EasyFrame
from tkinter import *
import tkinter.font as tkFont

class window(EasyFrame): #Main window for the game
    def __init__(self):
        EasyFrame.__init__(self, title="Turn-Based Game", width= 600, height= 500)
        self.setResizable(False)


        self.playerImageLabel = self.addLabel(text="", row=1, column=1) #Label for the player image
        self.playerImageLabel.place(x=10, y=175,)
        self.playerImage = PhotoImage(file="Player.gif")
        self.playerImageLabel["image"] = self.playerImage

        self.enemyImageLabel = self.addLabel(text="", row=1, column=1) #Label for the enemy image
        self.enemyImageLabel.place(x=400, y=75,)
        self.enemyImage = PhotoImage(file="enemy.gif")
        self.enemyImageLabel["image"] = self.enemyImage

        self.blankImage = PhotoImage(file="blankImage.gif") #Allows an image to be replaced with a blank .gif file


        self.playerTextLabel = self.addLabel(text=playerDisplayMessage, row=4, column=0, background="#CCCCCC") #Label for the message box beneath the player
        self.playerTextLabel.place(x=0, y=300, width=290, height=50)

        self.enemyTextLabel = self.addLabel(text=enemyDisplayMessage, row=4, column=9, background="#CCCCCC") #Label for the message box beneath the enemy
        self.enemyTextLabel.place(x=310, y=300, width=275, height=50)

        self.playerHealthLabel = self.addLabel(text=("Player", playerHealth), row=0, column=0) #Label for the player's health
        self.playerHealthLabel.place(x=0, y=0, width=150, height=50)
        ft = tkFont.Font(family='Times',size=20)
        self.playerHealthLabel["font"]=ft

        self.enemyHealthLabel = self.addLabel(text=("Enemy", enemyHealth), row=0, column=10) #Label for the enemy's health
        self.enemyHealthLabel.place(x=440, y=0, width=150, height=50)        
        ft = tkFont.Font(family='Times',size=20)
        self.enemyHealthLabel["font"]=ft   

        self.endMessageLabel = self.addLabel(text=endMessage, row=0, column=3) #Label for the message that displays at the end of the game
        ft = tkFont.Font(family='Times',size=34)
        self.endMessageLabel["font"]=ft
        self.endMessageLabel.place(x=150, y=50, width=275, height=50)


        self.attackButton = self.addButton(text="Attack", command=self.attack, row = 8, column= 2) #Button for attacking
        self.attackButton["fg"] = "#ff0000"
        self.attackButton.place(x=20,y=390,width=250,height=40)

        self.healButton = self.addButton(text=("Heal", healLimit), command=self.heal, row = 8, column= 3) #Button for healing
        self.healButton["fg"] = "#00AA00"
        self.healButton.place(x=330,y=390,width=250,height=40)

        self.specialButton = self.addButton(text="Special", command=self.special, row = 9, column= 2) #Button for using special
        self.specialButton["fg"] = "#FFAA00"
        self.specialButton.place(x=20,y=440,width=250,height=40)

        self.exitButton = self.addButton(text="Exit", command=self.exit, row = 8, column=3) #Button for exiting the game
        self.exitButton.place(x=330,y=440,width=250,height=40)
        
    def attack(self): #Function for attacking the enemy
            global playerDamage
            global enemyHealth
            global endGame
            global playerHealth
            global playerDisplayMessage
            global enemyDisplayMessage
            global endMessage

            global damageDealtCount 
            global damageTakenCount 
            global playerMissCount 
            global playerCritCount 
            global enemyMissCount 
            global enemyCritCount 

            playerDamage = random.randint(10, 30) #Randomizes the damage dealt
            if playerDamage < 14: #If the damage is less than 14, the attack will miss
                playerDamage = 0
                playerDisplayMessage = ("Player's attack missed!")
                playerMissCount += 1
            elif playerDamage > 25: #If the damage is more than 25, the attack will be a critical hit
                playerDamage = int(playerDamage * 1.5)
                playerDisplayMessage = ("Player lands a critical hit for", playerDamage, "damage!")
                playerCritCount += 1
            else:
                playerDisplayMessage = ("Player attacks for", playerDamage, "damage!")
            self.playerTextLabel["text"] = (playerDisplayMessage) #Updates the display message
            enemyHealth -= playerDamage #Damages the enemy
            damageDealtCount += playerDamage
            if enemyHealth <= 0: #Checks to see if the enemy is defeated
                enemyHealth = 0
                self.enemyHealthLabel["text"] = ("Enemy", enemyHealth)
                endMessage = "You win!"
                self.endMessageLabel["text"] = endMessage
                self.enemyImageLabel["image"] = self.blankImage #Replaces the image of the enemy with the blank image
                endGame = True
            else: #If the enemy is not defeated, the enemy will do its turn
                self.enemyHealthLabel["text"] = ("Enemy", enemyHealth)

                #Enemy's turn
                enemyDamage = random.randint(15, 35) #Randomizes the damage dealt
                if enemyDamage < 19: #If the damage is less than 19, the attack will miss
                    enemyDamage = 0
                    enemyDisplayMessage = ("Enemy's attack missed!")
                    enemyMissCount += 1
                elif enemyDamage > 33: #If the damage is more than 33, the attack will be a critical hit
                    enemyDamage = int(enemyDamage * 1.5)
                    enemyDisplayMessage = ("Enemy lands a critical hit for", enemyDamage, "damage!")
                    enemyCritCount += 1
                else:
                    enemyDisplayMessage = ("Enemy attacks for", enemyDamage, "damage!")
                self.enemyTextLabel["text"] = (enemyDisplayMessage) #Updates the display message
                playerHealth -= enemyDamage
                damageTakenCount += enemyDamage
                if playerHealth <= 0: #Checks to see if the player is defeated
                    playerHealth = 0
                    self.playerHealthLabel["text"] = ("Player", playerHealth)
                    endMessage = "You lose!"
                    self.endMessageLabel["text"] = endMessage
                    self.playerImageLabel["image"] = self.blankImage
                    endGame = True
                else: 
                    self.playerHealthLabel["text"] = ("Player", playerHealth)
            if endGame == True: #If the game is over, all buttons besides the exit button will be disabled
                self.specialButton["state"] = "disabled"
                self.attackButton["state"] = "disabled"
                self.healButton["state"] = "disabled"

    def heal(self): #Function for healing the player
            global healLimit
            global playerHealth
            global endGame
            
            global playerHealCount 
            global damageTakenCount 
            global enemyMissCount 
            global enemyCritCount 

            healamount = random.randint(40, 100) #Randomizes the amount healed
            playerHealth += healamount
            playerHealCount += healamount
            if playerHealth > 100: #Prevents the player from having more than 100 health
                playerHealth = 100
            self.playerHealthLabel["text"] = ("Player", playerHealth) #Updates the labels
            playerDisplayMessage = ("Player healed up to", playerHealth, "health!")
            self.playerTextLabel["text"] = (playerDisplayMessage)

            healLimit = healLimit - 1 #Lowers the heal limit by 1
            self.healButton["text"] = ("Heal", healLimit) 

            if healLimit <= 0: #If the heal limit is 0, it disables the healing button
                self.healButton["state"] = "disabled"
            
            #Enemy's turn
            enemyDamage = random.randint(15, 35) #Randomizes the damage dealt
            if enemyDamage < 19: #If the damage is less than 19, the attack will miss
                enemyDamage = 0
                enemyDisplayMessage = ("Enemy's attack missed!")
                enemyMissCount += 1
            elif enemyDamage > 33: #If the damage is more than 33, the attack will be a critical hit
                enemyDamage = int(enemyDamage * 1.5)
                enemyDisplayMessage = ("Enemy lands a critical hit for", enemyDamage, "damage!")
                enemyCritCount += 1
            else:
                enemyDisplayMessage = ("Enemy attacks for", enemyDamage, "damage!")
            self.enemyTextLabel["text"] = (enemyDisplayMessage) #Updates the display message
            playerHealth -= enemyDamage
            damageTakenCount += enemyDamage
            if playerHealth <= 0: #Checks to see if the player is defeated
                playerHealth = 0
                self.playerHealthLabel["text"] = ("Player", playerHealth)
                endMessage = "You lose!"
                self.endMessageLabel["text"] = endMessage
                self.playerImageLabel["image"] = self.blankImage
                endGame = True
            else:
                self.playerHealthLabel["text"] = ("Player", playerHealth)

            if endGame == True: #If the game is over, all buttons besides the exit button will be disabled
                self.specialButton["state"] = "disabled"
                self.attackButton["state"] = "disabled"
                self.healButton["state"] = "disabled"

    def special(self): #Function for the special button
            global specialDamage
            global enemyHealth
            global endGame
            global playerHealth
            global playerDisplayMessage
            global enemyDisplayMessage

            global damageDealtCount 
            global damageTakenCount 
            global enemyMissCount 
            global enemyCritCount 

            self.specialButton["state"] = "disabled" #Disables the button after it is pressed

            specialDamage = (115 - playerHealth) #Deals damage based on how much damage the player has taken
            playerDisplayMessage = ("Player uses special for", specialDamage, "damage!")
            self.playerTextLabel["text"] = (playerDisplayMessage) #Updates labels
            enemyHealth -= specialDamage #Damages the enemy
            damageDealtCount += specialDamage
            if enemyHealth <= 0: #Checks to see if the enemy is defeated
                enemyHealth = 0
                self.enemyHealthLabel["text"] = ("Enemy", enemyHealth)
                endMessage = "You win!"
                self.endMessageLabel["text"] = endMessage
                self.enemyImageLabel["image"] = self.blankImage
                endGame = True
            else:
                self.enemyHealthLabel["text"] = ("Enemy", enemyHealth)

                    
                #Enemy's turn
                enemyDamage = random.randint(15, 35) #Randomizes the damage dealt
                if enemyDamage < 19: #If the damage is less than 19, the attack will miss
                    enemyDamage = 0
                    enemyDisplayMessage = ("Enemy's attack missed!")
                    enemyMissCount += 1
                elif enemyDamage > 33: #If the damage is more than 33, the attack will be a critical hit
                    enemyDamage = int(enemyDamage * 1.5)
                    enemyDisplayMessage = ("Enemy lands a critical hit for", enemyDamage, "damage!")
                    enemyCritCount += 1
                else:
                    enemyDisplayMessage = ("Enemy attacks for", enemyDamage, "damage!")
                self.enemyTextLabel["text"] = (enemyDisplayMessage) #Updates the display message
                playerHealth -= enemyDamage
                damageTakenCount += enemyDamage
                if playerHealth <= 0: #Checks to see if the player is defeated
                    playerHealth = 0
                    self.playerHealthLabel["text"] = ("Player", playerHealth)
                    endMessage = "You lose!"
                    self.endMessageLabel["text"] = endMessage
                    self.playerImageLabel["image"] = self.blankImage
                    endGame = True
                else: 
                    self.playerHealthLabel["text"] = ("Player", playerHealth)
            if endGame == True: #If the game is over, all buttons besides the exit button will be disabled
                self.specialButton["state"] = "disabled"
                self.attackButton["state"] = "disabled"
                self.healButton["state"] = "disabled"
    
    def exit(self):
         window.destroy(self)
def main():
    window().mainloop()
if __name__ == "__main__":
    main()
class window2(EasyFrame): #Window for the end-of-game statistics
    def __init__(self):
        EasyFrame.__init__(self, title="Statistics", width= 400, height= 300)
        self.setResizable(False)

        self.titleLabel = self.addLabel(text="Statistics", row=0, column=3) #Label for the title
        ft = tkFont.Font(family='Times',size=34)
        self.titleLabel["font"]=ft
        self.titleLabel.place(x=65, y=50, width=275, height=50)

        #Labels for all of the counters
        
        self.damageDealtLabel = self.addLabel(text=("Damage Dealt", damageDealtCount), row =0, column=0,)
        self.damageDealtLabel.place(x=125, y=120, width=150, height=15)

        self.damageTakenLabel = self.addLabel(text=("Damage Taken", damageTakenCount), row =0, column=0,)
        self.damageTakenLabel.place(x=125, y=140, width=150, height=15)

        self.playerMissLabel = self.addLabel(text=("Player Attacks Missed", playerMissCount), row =0, column=0,)
        self.playerMissLabel.place(x=125, y=160, width=150, height=15)

        self.playerCritLabel = self.addLabel(text=("Player Critical Hits", playerCritCount), row =0, column=0,)
        self.playerCritLabel.place(x=125, y=180, width=150, height=15)

        self.playerHealLabel = self.addLabel(text=("Player Health Healed", playerHealCount), row =0, column=0,)
        self.playerHealLabel.place(x=125, y=200, width=150, height=15)

        self.enemyMissLabel = self.addLabel(text=("Enemy Attacks Missed", enemyMissCount), row =0, column=0,)
        self.enemyMissLabel.place(x=125, y=220, width=150, height=15)

        self.enemyCritLabel = self.addLabel(text=("Enemy Critical Hits", enemyCritCount), row =0, column=0,)
        self.enemyCritLabel.place(x=125, y=240, width=150, height=15)                        

def main():
    window2().mainloop()
if __name__ == "__main__":
    main()